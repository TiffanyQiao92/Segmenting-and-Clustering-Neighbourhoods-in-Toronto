# Segmenting-and-Clustering-Neighborhoods-of-Toronto-Coursera_Capstone
## This repository contains files pertaining to Week 3 assignment of IBM Applied Data Science Capstone Course on Coursera
## In this assignment we were required to explore, segment, and cluster the neighborhoods in the city of Toronto
